module d_ff (D, clk, reset_, Q);
   
        input D, clk, reset_;
        output Q;

        wire Qm, Qs;

	reg Q;
		  
	always @ (posedge clk or negedge reset_) begin
		if (!reset_)
			Q <= 1'b0;
		else 
			Q <= D;
	end
		  
endmodule


