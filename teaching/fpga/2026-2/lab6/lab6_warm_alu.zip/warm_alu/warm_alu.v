//==========================================
// warm_alu.v : 뺄셈과 Z·N 을 단 계산기 - top
// Lab 3 Part5 계산기에서 adder_8bit 자리에 alu_8bit
// SW[7:0] = 수, SW[8] = 0 덧셈 / 1 뺄셈
// KEY[1] = 지금 수를 A 로 저장, KEY[0] = 리셋
// HEX5~4 = 결과, HEX3~2 = A(저장한 수), HEX1~0 = B(스위치 수)
// LEDR[2] = N, LEDR[1] = Z, LEDR[0] = 올림/빌림
//==========================================
module warm_alu (SW, KEY, LEDR, HEX0, HEX1, HEX2, HEX3, HEX4, HEX5);

    input  wire [8:0] SW;      // [7:0] 수, [8] AddSub
    input  wire [1:0] KEY;     // [1] 저장, [0] 리셋
    output wire [9:0] LEDR;
    output wire [0:6] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5;

    wire [7:0] A;              // 저장한 수
    wire [7:0] S;              // 결과
    wire       Cout, Z, N;

    // 저장: Lab 3 의 register_8bit (KEY[1] 을 클럭으로)
    register_8bit u0 (SW[7:0], KEY[1], KEY[0], A);

    // 계산: A (+/-) B, B = 스위치 수
    alu_8bit u1 (A, SW[7:0], SW[8], S, Cout, Z, N);

    hex_dec d0 (SW[3:0], HEX0);
    hex_dec d1 (SW[7:4], HEX1);

    hex_dec d2 (A[3:0], HEX2);
    hex_dec d3 (A[7:4], HEX3);

    hex_dec d4 (S[3:0], HEX4);
    hex_dec d5 (S[7:4], HEX5);

    assign LEDR = {7'b0000000, N, Z, Cout};

endmodule
