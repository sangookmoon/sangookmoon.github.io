module register_8bit (reg_in, clk, reset_, reg_out);
	
	input [7:0] reg_in;
	input clk, reset_;
	output [7:0] reg_out;

	d_ff u0 (reg_in[0], clk, reset_, reg_out[0]);
	d_ff u1 (reg_in[1], clk, reset_, reg_out[1]);
	d_ff u2 (reg_in[2], clk, reset_, reg_out[2]);
	d_ff u3 (reg_in[3], clk, reset_, reg_out[3]);
	d_ff u4 (reg_in[4], clk, reset_, reg_out[4]);
	d_ff u5 (reg_in[5], clk, reset_, reg_out[5]);
	d_ff u6 (reg_in[6], clk, reset_, reg_out[6]);
	d_ff u7 (reg_in[7], clk, reset_, reg_out[7]);

endmodule

