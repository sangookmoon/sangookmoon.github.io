`timescale 1ns/1ps
module tb_alu;
  reg  [8:0] SW  = 9'd0;
  reg  [1:0] KEY = 2'b11;     // 평소 1, 누르면 0
  wire [9:0] LEDR;
  wire [0:6] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5;

  warm_alu dut (SW, KEY, LEDR,
                HEX0, HEX1, HEX2, HEX3, HEX4, HEX5);

  // $display 글자는 영어로 (ModelSim 은 한글을 깨뜨린다)
  initial begin
    #10 KEY[0] = 0;            // 리셋 버튼
    #10 KEY[0] = 1;

    // 13 - 4 : A = 13 저장 → B = 4, 뺄셈
    #10 SW[7:0] = 8'd13;
    #10 KEY[1] = 0;            // 누름
    #10 KEY[1] = 1;            // 뗌 → A 에 저장
    #10 SW[7:0] = 8'd4;  SW[8] = 1;
    #10 $display("%0d - %0d  : S = %h  Z=%b N=%b   (expect 09, Z=0 N=0)",
                 dut.A, SW[7:0], dut.S, LEDR[1], LEDR[2]);

    // 3 - 5
    #10 SW[7:0] = 8'd3;
    #10 KEY[1] = 0;
    #10 KEY[1] = 1;
    #10 SW[7:0] = 8'd5;  SW[8] = 1;
    #10 $display("%0d - %0d  : S = %h  Z=%b N=%b   (expect fe, Z=0 N=1)",
                 dut.A, SW[7:0], dut.S, LEDR[1], LEDR[2]);

    // 4 - 4
    #10 SW[7:0] = 8'd4;
    #10 KEY[1] = 0;
    #10 KEY[1] = 1;
    #10 SW[7:0] = 8'd4;  SW[8] = 1;
    #10 $display("%0d - %0d  : S = %h  Z=%b N=%b   (expect 00, Z=1 N=0)",
                 dut.A, SW[7:0], dut.S, LEDR[1], LEDR[2]);

    // 13 + 6
    #10 SW[7:0] = 8'd13;
    #10 KEY[1] = 0;
    #10 KEY[1] = 1;
    #10 SW[7:0] = 8'd6;  SW[8] = 0;
    #10 $display("%0d + %0d  : S = %h  Z=%b N=%b   (expect 13 = 19 decimal, Z=0 N=0)",
                 dut.A, SW[7:0], dut.S, LEDR[1], LEDR[2]);

    #10 $stop;
  end
endmodule
