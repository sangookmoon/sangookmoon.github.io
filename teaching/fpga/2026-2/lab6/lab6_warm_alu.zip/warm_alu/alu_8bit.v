//==========================================
// alu_8bit.v : 덧셈·뺄셈 + 플래그 Z, N
// Lab 3 adder_8bit 에 AddSub 를 더했다
// AddSub = 0 → S = A + B,  1 → S = A - B
//==========================================
module alu_8bit (A, B, AddSub, S, Cout, Z, N);

    input  wire [7:0] A;            // 저장한 수 (HEX3~2)
    input  wire [7:0] B;            // 스위치 수 (HEX1~0)
    input  wire       AddSub;       // 0 덧셈, 1 뺄셈
    output reg  [7:0] S;            // 결과 (HEX5~4)
    output reg        Cout;         // 덧셈: 올림, 뺄셈: 빌림
    output wire       Z;            // 결과가 0이면 1
    output wire       N;            // 결과가 음수면 1

    always @(*) begin
        {Cout, S} = A + B;              // 기본값: 덧셈
        case (AddSub)
            1'b0:    {Cout, S} = A + B;     // 덧셈
            1'b1:    {Cout, S} = ? ? ?;     // 빈칸 1: 뺄셈
            default: {Cout, S} = A + B;
        endcase
    end

    assign Z = ? ? ?;               // 빈칸 2: 결과가 0인가
    assign N = ? ? ?;               // 빈칸 3: 맨 왼쪽 비트 = 부호

endmodule
