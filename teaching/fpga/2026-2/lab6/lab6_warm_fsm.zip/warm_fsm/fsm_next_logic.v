// 2. 다음 상태 결정 : 현재 단계 + Run, op → 다음 단계
module fsm_next_logic (state, Run, op, next_state);

    input  wire [1:0] state;        // 현재 단계
    input  wire       Run;          // 1이면 실행
    input  wire [1:0] op;           // 명령 종류 (op코드)
    output reg  [1:0] next_state;

    localparam T0 = 2'b00;
    localparam T1 = 2'b01;
    localparam T2 = 2'b10;
    localparam T3 = 2'b11;

    localparam MV  = 2'b00;         // op : 00 mv
    localparam ADD = 2'b01;         //      01 add
    localparam SUB = 2'b10;         //      10 sub
    localparam BR  = 2'b11;         //      11 분기

    always @(*) begin
        next_state = state;         // 기본값: 그대로
        case (state)
            T0: if (? ? ?) next_state = T1;                   // 빈칸 1
            T1: if (? ? ?)                    next_state = T2; // 빈칸 2
                else                          next_state = T0;
            T2:                               next_state = T3;
            T3:                               next_state = T0;
            default:                          next_state = T0;
        endcase
    end

endmodule
