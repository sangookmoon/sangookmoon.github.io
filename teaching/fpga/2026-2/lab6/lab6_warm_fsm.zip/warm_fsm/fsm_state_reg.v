// 1. 상태 레지스터 : 세 블록 중 유일한 플립플롭
// en 이 1인 클럭에서만 한 단계 나아간다
module fsm_state_reg (clock, reset_n, en, next_state, state);

    input  wire       clock;        // CLOCK_50
    input  wire       reset_n;      // KEY[0]
    input  wire       en;           // 1초 tick
    input  wire [1:0] next_state;   // 2 의 결과
    output reg  [1:0] state;        // 현재 단계

    always @(posedge clock or negedge reset_n) begin
        if (!reset_n)
            state <= 2'b00;         // T0
        else if (en)
            state <= next_state;
    end

endmodule
