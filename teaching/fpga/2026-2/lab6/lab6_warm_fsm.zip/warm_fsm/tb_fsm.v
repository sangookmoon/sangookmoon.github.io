`timescale 1ns/1ps
module tb_fsm;
  reg        CLOCK_50 = 0;
  reg  [9:0] SW  = 10'd0;
  reg  [1:0] KEY = 2'b11;      // 평소 1, 누르면 0
  wire [9:0] LEDR;
  wire [0:6] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5;

  // 1초 대신 5클럭(100 ns)마다 tick
  warm_fsm #(.TICK_MAX(26'd4)) dut (CLOCK_50, SW, KEY, LEDR,
                HEX0, HEX1, HEX2, HEX3, HEX4, HEX5);

  always #10 CLOCK_50 = ~CLOCK_50;   // 50 MHz

  // tick 이 1인 클럭(= 한 단계 나아가는 클럭)마다 한 줄 출력
  // 스위치는 tick 이 지나고 5 ns 뒤에 바꾼다
  // $display 글자는 영어로 (ModelSim 은 한글을 깨뜨린다)
  always @(posedge CLOCK_50)
    if (dut.tick) #1 $display("%4d ns  Run=%b op=%b  ->  T%0d   LEDR[3:0]=%b",
                $time, SW[9], SW[7:6], dut.state, LEDR[3:0]);

  initial begin
    #15  KEY[0] = 0;           // 리셋 버튼
    #20  KEY[0] = 1;

    $display("--- Run=0 : stay T0 (expect T0 T0 T0)");
    SW[9] = 0; SW[7:6] = 2'b00;
    repeat (3) @(negedge dut.tick);

    #5 $display("--- Run=1, op=00 mv  (expect T1 T0 T1 T0)");
    SW[9] = 1; SW[7:6] = 2'b00;
    repeat (4) @(negedge dut.tick);

    #5 $display("--- Run=1, op=01 add (expect T1 T2 T3 T0)");
    SW[7:6] = 2'b01;
    repeat (4) @(negedge dut.tick);

    #5 $display("--- Run=1, op=10 sub (expect T1 T2 T3 T0)");
    SW[7:6] = 2'b10;
    repeat (4) @(negedge dut.tick);

    #5 $display("--- Run=1, op=11 branch (expect T1 T0)");
    SW[7:6] = 2'b11;
    repeat (2) @(negedge dut.tick);

    #5 $display("--- Run=0 : stay T0 (expect T0 T0)");
    SW[9] = 0;
    repeat (2) @(negedge dut.tick);

    #10 $stop;
  end
endmodule
