//==========================================
// warm_fsm.v : 단계만 세는 제어 FSM - top
// 프로세서 제어 FSM 의 단계(T0~T3) 흐름만 본다
// SW[9] = Run, SW[7:6] = op (00 mv 01 add 10 sub 11 분기)
// KEY[0] = 리셋, 1초마다 한 단계
// HEX1~0 = 「t0」~「t3」, LEDR[3:0] = 단계 (불 하나)
//==========================================
module warm_fsm (CLOCK_50, SW, KEY, LEDR, HEX0, HEX1, HEX2, HEX3, HEX4, HEX5);

    input  wire       CLOCK_50;
    input  wire [9:0] SW;      // [9] Run, [7:6] op
    input  wire [1:0] KEY;     // [0] 리셋
    output wire [9:0] LEDR;
    output wire [0:6] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5;

    parameter TICK_MAX = 26'd49_999_999;   // 1초

    wire [1:0] state;          // 현재 단계
    wire [1:0] next_state;     // 다음 단계
    wire       tick;           // 1초에 한 클럭만 1
    wire [3:0] onehot;

    // 1초 tick : Lab 4 Part3 의 big_counter
    big_counter #(.MAX(TICK_MAX)) u0 (CLOCK_50, KEY[0], 1'b1, tick);
    // 1. 상태 레지스터
    fsm_state_reg  u1 (CLOCK_50, KEY[0], tick, next_state, state);
    // 2. 다음 상태 결정
    fsm_next_logic u2 (state, SW[9], SW[7:6], next_state);
    // 3. 출력 결정
    fsm_out_logic  u3 (state, HEX1, HEX0, onehot);

    assign LEDR = {6'b000000, onehot};
    assign HEX2 = 7'b1111111;  // 나머지 HEX 는 끔
    assign HEX3 = 7'b1111111;
    assign HEX4 = 7'b1111111;
    assign HEX5 = 7'b1111111;

endmodule
