module big_counter (clock, reset_n, enable, E);

    input  wire clock;          // CLOCK_50
    input  wire reset_n;        // active-low reset
    input  wire enable;
    output reg  E;              // 1초 펄스

    parameter MAX = 26'd49_999_999;

    reg [25:0] big_count;

    always @(posedge clock or negedge reset_n) begin
        if (!reset_n) begin
            big_count <= 26'd0;
            E         <= 1'b0;
        end
        else if (!enable) begin
            big_count <= big_count;   // 멈춤
            E         <= 1'b0;
        end
        else if (big_count == MAX) begin
            big_count <= 26'd0;
            E         <= 1'b1;        // 여기서만 1클럭 동안 1
        end
        else begin
            big_count <= big_count + 1'b1;
            E         <= 1'b0;
        end
    end

endmodule
