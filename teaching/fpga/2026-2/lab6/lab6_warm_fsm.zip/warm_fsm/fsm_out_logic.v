// 3. 출력 결정 : 현재 단계 → HEX1~0 「t0」~「t3」, LEDR[3:0]
module fsm_out_logic (state, HEX1, HEX0, onehot);

    input  wire [1:0] state;        // 현재 단계
    output wire [0:6] HEX1, HEX0;
    output reg  [3:0] onehot;       // 단계마다 불 하나

    localparam T0 = 2'b00;
    localparam T1 = 2'b01;
    localparam T2 = 2'b10;
    localparam T3 = 2'b11;

    always @(*) begin
        onehot = 4'b0000;           // 기본값: 모두 끔
        case (state)
            T0:      onehot = 4'b0001;
            T1:      onehot = 4'b0010;
            T2:      onehot = 4'b0100;
            T3:      onehot = 4'b1000;
            default: onehot = 4'b0000;
        endcase
    end

    assign HEX1 = 7'b1110000;       // 글자 t (Lab 5 char_hex_dec 의 t)
    hex_dec d0 ({2'b00, state}, HEX0);   // 숫자 0~3

endmodule
