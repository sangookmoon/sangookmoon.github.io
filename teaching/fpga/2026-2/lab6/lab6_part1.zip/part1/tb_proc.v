`timescale 1ns/1ps
module tb_proc;
  reg        Clock = 0, reset_n = 1, Run = 1;
  wire [7:0] DIN, BusWires, R0, R1, R2;
  wire [3:0] PC;
  wire [1:0] Tstep;
  wire       Done;

  rom  u_rom (.addr(PC), .data(DIN));
  proc dut (.Clock(Clock), .En(1'b1), .reset_n(reset_n), .Run(Run),
            .DIN(DIN), .PC(PC), .Done(Done), .BusWires(BusWires),
            .R0(R0), .R1(R1), .R2(R2), .Tstep(Tstep));

  always #10 Clock = ~Clock;     // 20 ns

  initial begin
    #5  reset_n = 0;             // 리셋 버튼
    #10 reset_n = 1;
    #1200 $display("q = r2 = %0d, r = r0 = %0d", R2, R0);
    $stop;
  end
endmodule
