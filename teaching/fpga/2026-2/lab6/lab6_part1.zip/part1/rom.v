// rom.v : 프로그램 — 유클리드 나눗셈 13 ÷ 4  (r0 = 나머지, r2 = 몫)
module rom (input wire [3:0] addr, output reg [7:0] data);
    always @(*) begin
        case (addr)
            4'd0: data = 8'h27;   //       mv  r0, #7
            4'd1: data = 8'h66;   //       add r0, #6     ; r0 = 13 (나눌 수)
            4'd2: data = 8'h2C;   //       mv  r1, #4     ; r1 = 4  (나누는 수)
            4'd3: data = 8'h30;   //       mv  r2, #0     ; r2 = 0  (몫)
            4'd4: data = 8'h81;   // LOOP: sub r0, r1
            4'd5: data = 8'hF8;   //       bmi DONE       ; 음수가 되면 끝
            4'd6: data = 8'h71;   //       add r2, #1     ; 몫 + 1
            4'd7: data = 8'hC4;   //       b   LOOP
            4'd8: data = 8'h41;   // DONE: add r0, r1     ; 한 번 더 뺀 것을 되돌림
            4'd9: data = 8'hC9;   // END:  b   END        ; 멈춤
            default: data = 8'hC9;
        endcase
    end
endmodule
