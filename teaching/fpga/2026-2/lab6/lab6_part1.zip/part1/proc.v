//==========================================
// proc.v : 간단한 8비트 프로세서 (Lab 6)
// 명령 : mv / add / sub (rY 또는 #D), b / beq / bne / bmi
// 형식 : op(2) IMM(1) rX(2) rY/#D(3)   분기: 11 CC(2) 주소(4)
//==========================================

module proc (
    input  wire       Clock,
    input  wire       En,        // 1인 클럭에서만 한 단계 진행
    input  wire       reset_n,   // 0이면 리셋
    input  wire       Run,       // 1이면 실행, 0이면 멈춤
    input  wire [7:0] DIN,       // ROM에서 온 명령
    output wire [3:0] PC,        // ROM 주소
    output reg        Done,
    output reg  [7:0] BusWires,
    output wire [7:0] R0, R1, R2,
    output wire [1:0] Tstep      // 현재 단계 (= state)
);

    //----------------------------------------
    // 1. 명령어 칸과 상태(단계) 이름
    //----------------------------------------
    reg  [7:0] IR;
    wire [1:0] op  = IR[7:6];        // 00 mv 01 add 10 sub 11 분기
    wire       IMM = IR[5];
    wire [1:0] rX  = IR[4:3];
    wire [1:0] rY  = IR[1:0];
    wire [7:0] D   = {5'b0, IR[2:0]};
    wire [1:0] CC  = IR[5:4];        // 분기 조건
    wire [3:0] ADR = IR[3:0];        // 분기할 주소

    localparam MV = 2'b00, ADD = 2'b01, SUB = 2'b10, BR = 2'b11;
    localparam T0 = 2'd0, T1 = 2'd1, T2 = 2'd2, T3 = 2'd3;
    localparam SEL_D = 3'd4, SEL_G = 3'd5;

    reg [3:0] pc;
    reg       Z, N;                  // 마지막 add·sub: 0? 음수?

    //----------------------------------------
    // 2. 분기 조건이 맞는가 (take)
    //----------------------------------------
    reg take;
    always @(*) begin
        take = 1'b0;                 // 기본값
        case (CC)
            2'b00: take = 1'b0;      // 빈칸: b   (항상)
            2'b01: take = 1'b0;      // 빈칸: beq (0이면)
            2'b10: take = 1'b0;      // 빈칸: bne (0이 아니면)
            2'b11: take = 1'b0;      // 빈칸: bmi (음수면)
            default: take = 1'b0;
        endcase
    end

    //----------------------------------------
    // 3. 상태 레지스터 (순차 회로: always)
    //----------------------------------------
    reg [1:0] state, next_state;
    always @(posedge Clock or negedge reset_n) begin
        if (!reset_n)  state <= T0;
        else if (En)   state <= next_state;
    end

    //----------------------------------------
    // 4. 다음 상태 결정 (조합 회로: always @(*) + case)
    //----------------------------------------
    always @(*) begin
        next_state = state;          // 기본값: 그대로
        case (state)
            T0: if (Run) next_state = T1;
            T1: if (op == ADD || op == SUB) next_state = T2;
                else                          next_state = T0;
            T2: next_state = T3;
            T3: next_state = T0;
            default: next_state = T0;
        endcase
    end

    //----------------------------------------
    // 5. 출력 결정: 제어 신호 (조합 회로: always @(*) + case)
    //----------------------------------------
    reg IRin, Ain, Gin, AddSub, Rin, PCin;
    reg [2:0] Sel;
    always @(*) begin
        IRin = 1'b0; Ain = 1'b0; Gin = 1'b0; AddSub = 1'b0;
        Rin = 1'b0; PCin = 1'b0; Done = 1'b0; Sel = SEL_G;
        case (state)
            T0: IRin = Run;                    // IR <- ROM[pc], pc+1
            T1: case (op)
                    MV:  begin                 // rX <- rY/#D
                             Sel = IMM ? SEL_D : {1'b0, rY};
                             Rin = 1'b1; Done = 1'b1;
                         end
                    BR:  begin                 // 조건이 맞으면 pc <- 주소
                             PCin = take; Done = 1'b1;
                         end
                    default: begin             // add, sub: A <- rX
                             Sel = {1'b0, rX}; Ain = 1'b1;
                         end
                endcase
            T2: begin                          // G <- A +/- rY/#D
                    // 빈칸: rY/#D 를 버스에 (Sel)
                    // 빈칸: 뺄셈이면 AddSub = 1, Gin
                end
            T3: begin                          // rX <- G
                    // 빈칸: G를 버스에, Rin, Done
                end
            default: ;
        endcase
    end

    //----------------------------------------
    // 6. 데이터 경로: 레지스터와 버스 MUX
    //----------------------------------------
    reg  [7:0] r0, r1, r2, r3, A, G;
    wire [7:0] result = AddSub ? A - BusWires : A + BusWires;

    always @(posedge Clock or negedge reset_n) begin
        if (!reset_n) begin
            IR <= 8'd0; A <= 8'd0; G <= 8'd0; pc <= 4'd0; Z <= 1'b0; N <= 1'b0;
            r0 <= 8'd0; r1 <= 8'd0; r2 <= 8'd0; r3 <= 8'd0;
        end
        else if (En) begin
            if (IRin) begin IR <= DIN; pc <= pc + 1'b1; end
            if (PCin) pc <= ADR;       // IRin 과 PCin 은 같은 단계에 켜지지 않는다
            if (Ain)  A  <= BusWires;
            if (Gin)  begin G <= result; Z <= (result == 8'd0); N <= result[7]; end
            if (Rin)
                case (rX)
                    2'd0: r0 <= BusWires;
                    2'd1: r1 <= BusWires;
                    2'd2: r2 <= BusWires;
                    2'd3: r3 <= BusWires;
                endcase
        end
    end

    always @(*) begin
        case (Sel)
            3'd0: BusWires = r0;   3'd1: BusWires = r1;
            3'd2: BusWires = r2;   3'd3: BusWires = r3;
            SEL_D: BusWires = D;
            default: BusWires = G;
        endcase
    end

    assign PC = pc;  assign Tstep = state;
    assign R0 = r0;  assign R1 = r1;  assign R2 = r2;

endmodule
