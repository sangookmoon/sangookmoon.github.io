// rom_gcd.v : 프로그램 — 최대공약수 gcd(12, 8)  (결과 r0)
module rom (input wire [3:0] addr, output reg [7:0] data);
    always @(*) begin
        case (addr)
            4'd0:  data = 8'h26;  //        mv  r0, #6
            4'd1:  data = 8'h66;  //        add r0, #6     ; r0 = 12
            4'd2:  data = 8'h2C;  //        mv  r1, #4
            4'd3:  data = 8'h6C;  //        add r1, #4     ; r1 = 8
            4'd4:  data = 8'h10;  // LOOP:  mv  r2, r0
            4'd5:  data = 8'h91;  //        sub r2, r1     ; r2 = r0 - r1
            4'd6:  data = 8'hDC;  //        beq DONE       ; 같으면 끝
            4'd7:  data = 8'hFA;  //        bmi R1BIG      ; r0 < r1
            4'd8:  data = 8'h02;  //        mv  r0, r2     ; r0 = r0 - r1
            4'd9:  data = 8'hC4;  //        b   LOOP
            4'd10: data = 8'h88;  // R1BIG: sub r1, r0     ; r1 = r1 - r0
            4'd11: data = 8'hC4;  //        b   LOOP
            4'd12: data = 8'hCC;  // DONE:  b   DONE
            default: data = 8'hCC;
        endcase
    end
endmodule
