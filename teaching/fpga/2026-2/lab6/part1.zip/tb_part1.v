`timescale 1ns/1ps
module tb_part1;
  reg        Clock = 0, reset_n = 1, Run = 1;
  reg  [7:0] DIN = 8'h27;          // 처음 명령 : mv r0, #7
  wire [7:0] BusWires, R0, R1, R2;
  wire [3:0] PC;
  wire [1:0] Tstep;
  wire       Done;

  proc dut (.Clock(Clock), .En(1'b1), .reset_n(reset_n), .Run(Run),
            .DIN(DIN), .PC(PC), .Done(Done), .BusWires(BusWires),
            .R0(R0), .R1(R1), .R2(R2), .Tstep(Tstep));

  always #10 Clock = ~Clock;       // 20 ns

  initial begin
    #5  reset_n = 0;               // 리셋 버튼
    #10 reset_n = 1;
  end

  // 스위치 바꾸기 : 명령이 끝나 T0 으로 돌아온 뒤, 다음 에지 전에
  initial begin
    #60  DIN = 8'h66;              // add r0, #6   (mv 는 2클럭)
    #80  DIN = 8'h2C;              // mv  r1, #4   (add 는 4클럭)
    #40  DIN = 8'h81;              // sub r0, r1
    #80  Run = 0;                  // Run 내림 : T0 에서 기다린다
    #60  $display("r0 = %h, r1 = %h, r2 = %h, pc = %0d", R0, R1, R2, PC);
    $stop;
  end
endmodule
