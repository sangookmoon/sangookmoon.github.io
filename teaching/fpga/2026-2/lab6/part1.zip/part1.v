//==========================================
// part1.v : 명령어를 스위치로 넣고 한 단계씩 실행
// SW[7:0] = 명령어 8비트, SW[9] = Run
// KEY[0] = 리셋, KEY[1] = 한 단계 (누를 때마다 한 클럭)
// HEX5~4 = r0, HEX3~2 = r1, HEX1~0 = r2
// LEDR[9] = Done, LEDR[7:4] = pc, LEDR[1:0] = 단계
//==========================================

module part1 (
    input  wire       CLOCK_50,
    input  wire [9:0] SW,
    input  wire [1:0] KEY,
    output wire [9:0] LEDR,
    output wire [0:6] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5
);

    wire reset_n = KEY[0];                     // 누르면 0 → 리셋

    // 한 단계: KEY[1] 눌린 순간 한 클럭 (Lab 5 버튼 에지 + 클럭 맞추기)
    reg key_s, key_d;
    always @(posedge CLOCK_50) begin
        key_s <= KEY[1];                       // 클럭에 맞춘 KEY[1]
        key_d <= key_s;                        // 한 클럭 전 값
    end
    wire step = key_d & ~key_s;                // 1 → 0 으로 바뀐 순간

    wire [7:0] bus, r0, r1, r2;
    wire [3:0] pc;
    wire [1:0] tstep;
    wire       done;

    // 명령어는 ROM 대신 스위치에서 : DIN = SW[7:0]
    proc u_proc (
        .Clock(CLOCK_50), .En(step), .reset_n(reset_n), .Run(SW[9]),
        .DIN(SW[7:0]), .PC(pc), .Done(done), .BusWires(bus),
        .R0(r0), .R1(r1), .R2(r2), .Tstep(tstep));

    assign LEDR = {done, 1'b0, pc, 2'b00, tstep};

    hex_dec h5 (.bin(r0[7:4]), .hex(HEX5));
    hex_dec h4 (.bin(r0[3:0]), .hex(HEX4));
    hex_dec h3 (.bin(r1[7:4]), .hex(HEX3));
    hex_dec h2 (.bin(r1[3:0]), .hex(HEX2));
    hex_dec h1 (.bin(r2[7:4]), .hex(HEX1));
    hex_dec h0 (.bin(r2[3:0]), .hex(HEX0));

endmodule
