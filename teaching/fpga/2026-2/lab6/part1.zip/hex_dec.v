module hex_dec (bin, hex);

    input  wire [3:0] bin;
    output wire [0:6] hex;

    assign hex = (bin == 4'h0) ? 7'b0000001 :
                 (bin == 4'h1) ? 7'b1001111 :
                 (bin == 4'h2) ? 7'b0010010 :
                 (bin == 4'h3) ? 7'b0000110 :
                 (bin == 4'h4) ? 7'b1001100 :
                 (bin == 4'h5) ? 7'b0100100 :
                 (bin == 4'h6) ? 7'b0100000 :
                 (bin == 4'h7) ? 7'b0001111 :
                 (bin == 4'h8) ? 7'b0000000 :
                 (bin == 4'h9) ? 7'b0001100 :
                 (bin == 4'ha) ? 7'b0001000 :
                 (bin == 4'hb) ? 7'b1100000 :
                 (bin == 4'hc) ? 7'b1110010 :
                 (bin == 4'hd) ? 7'b1000010 :
                 (bin == 4'he) ? 7'b0110000 :
                 (bin == 4'hf) ? 7'b0111000 :
                                 7'b1111111;  // 그 밖: 모두 끔 (빈칸)

endmodule
